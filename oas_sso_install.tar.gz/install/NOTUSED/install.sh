#!/bin/bash

#export http_proxy=http://www-proxy.example.com:8080
#export https_proxy=http://www-proxy.example.com:8080

# Install httpd and required modules
yum install -y httpd mod_ssl mod_auth_kerb


# After installation of the package, you need to start and enable the httpd daemon
# ---------------------------------------------------------------------------------
/bin/systemctl enable httpd

# If Installing Shibboleth SP on Oracle Linux 7.x 
# --------------------------------------------------------------------------------------------------------------------------------
#wget http://download.opensuse.org/repositories/security://shibboleth/CentOS_7/security:shibboleth.repo -P /etc/yum.repos.d
#yum -y install shibboleth.x86_64

yum -y install bc initscripts iproute iptables iputils libevent libmemcached libmnl libnetfilter_conntrack libnfnetlink libtool-ltdl  sysvinit-tools unixODBC
yum -y clean all

rpm -ivh /install/*.rpm

# --------------------------------------------------------------------------------------------------------------------------------

# After installation of the package, you need to start and enable the shibd daemon
# ---------------------------------------------------------------------------------
/bin/systemctl enable shibd.service


# Copy packages to the new drive
# -------------------------------------------------------
cp /install/shibdapache /etc/init.d/shibdapache
cp /install/shibdapache-ctl /etc/init.d/shibdapache-ctl
cp /install/kerbapache /etc/init.d/kerbapache
cp /install/kerbapache-ctl /etc/init.d/kerbapache-ctl
chmod +x /etc/init.d/shibdapache
chmod +x /etc/init.d/shibdapache-ctl
chmod +x /etc/init.d/kerbapache
chmod +x /etc/init.d/kerbapache-ctl

# Copy shibboleth2.xml.sample to /etc/shibboleth 
cp /install/shibboleth2.xml.sample /etc/shibboleth/shibboleth2.xml.sample

# Copy attribute-map.xml.sample to /etc/shibboleth 
cp /install/attribute-map.xml.sample /etc/shibboleth/attribute-map.xml.sample


# Copy other files
# ----------------
cp /install/saml_analytics.conf /etc/httpd/conf.d/saml_analytics.conf
cp /install/kerb_analytics.conf /etc/httpd/conf.d/kerb_analytics.conf
cp /install/redirect_http_to_https.conf /etc/httpd/conf.d/redirect_http_to_https.conf
cp /install/rewrite_engine.conf /etc/httpd/conf.d/rewrite_engine.conf
cp /install/psr.conf /etc/httpd/conf.d/psr.conf
cp /install/config_Apache_SSL.sh /etc/httpd/conf.d/config_Apache_SSL.sh
cp /install/logout.html /var/www/html/logout.html
cp /install/change_Apache_Config.sh /etc/httpd/conf.d/change_Apache_Config.sh
cp /install/saml_analyticsclustered.conf.txt /etc/httpd/conf.d/saml_analyticsclustered.conf.txt
cp /install/kerb_analyticsclustered.conf.txt /etc/httpd/conf.d/kerb_analyticsclustered.conf.txt
cp /install/workers.conf.txt /etc/httpd/conf.d/workers.conf.txt
chmod +x /etc/httpd/conf.d/change_Apache_Config.sh
chmod +x /etc/httpd/conf.d/config_Apache_SSL.sh
sudo /sbin/chkconfig --add /etc/init.d/shibdapache-ctl
sudo /sbin/chkconfig shibdapache-ctl --level 2345 on
sudo /sbin/chkconfig --add /etc/init.d/kerbapache-ctl
sudo /sbin/chkconfig kerbapache-ctl --level 2345 on

# Changing Apache SSL cipher's and Protocol's
# -------------------------------------------------------
/etc/httpd/conf.d/change_Apache_Config.sh

# Copy the libcurl.so.4.7.0 from /opt/shibboleth/lib64 to /usr/lib64 delete the link and create same link with latest file
cd /opt/shibboleth/lib64
filename=`ls libcurl.so.4.*`
cp $filename /usr/lib64
cd /usr/lib64
rm -f libcurl.so.4
ln -s $filename libcurl.so.4

# Install completed
echo "Installation of httpd and shibboleth-sp is completed."

# Exit from docker container
exit
